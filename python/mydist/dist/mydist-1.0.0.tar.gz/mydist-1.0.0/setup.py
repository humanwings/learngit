from distutils.core import setup

setup(
    name        =   'mydist',
    version     =   '1.0.0',
    py_modules  =   ['commondist'],
    author      =   'wujian',
    author_email    =   'wujian@liandisys.com.cn',
    url         =   'http://wujian.liandisys.com.cn',
    description =   'a example print module of list'
)